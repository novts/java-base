import comp102x.Canvas;

public class Lab04GradedTask2
{
   public static void testCase1()
   {    
       Canvas canvas = new Canvas(480, 960);
       Choice choice1 = new Choice(0); //Rock
       choice1.draw(canvas, 0, 480, 0); 
   }
}
