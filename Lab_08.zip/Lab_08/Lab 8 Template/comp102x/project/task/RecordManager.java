package comp102x.project.task;

import comp102x.project.model.GameRecord;

public class RecordManager {

    public GameRecord[] updateGameRecords(GameRecord[] oldRecords, GameRecord newRecord) {
        
        // Please write your code after this line
        
        return oldRecords; // This line should be modified or removed upon finishing the implementation of this method.
    }
}
