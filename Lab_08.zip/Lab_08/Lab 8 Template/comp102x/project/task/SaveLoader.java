package comp102x.project.task;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import comp102x.project.model.GameRecord;

public class SaveLoader {
	
	public void saveGameRecords(GameRecord[] records, String filename) throws FileNotFoundException {
		
		// Please write your code after this line
	}
	
	public GameRecord[] loadGameRecords(String filename) throws FileNotFoundException {
		
		// Please write your code after this line
		
		return null; // This line should be modified or removed after finising the implementation of this method.
	}

}
