public class Moves {
    public int x;
    public int y;
    public int step;

    public Moves(int x, int y, int step) {
        this.x = x;
        this.y = y;
        this.step = step;
    }
}